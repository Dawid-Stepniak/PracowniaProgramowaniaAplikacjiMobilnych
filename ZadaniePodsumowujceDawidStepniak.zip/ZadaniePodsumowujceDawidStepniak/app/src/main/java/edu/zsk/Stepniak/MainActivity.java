package edu.zsk.Stepniak;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private SQLiteDatabase db;
    private EditText emailInput, passwordInput;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initDb();

        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginButton);

        loginButton.setOnClickListener(v -> {
            String email = emailInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Wypełnij wszystkie pola!", Toast.LENGTH_LONG).show();
                return;
            }

            if (!checkCredentials(email, password)) {
                Toast.makeText(this, "Niepoprawne dane logowania!", Toast.LENGTH_LONG).show();
                passwordInput.setText("");
                return;
            }

            Toast.makeText(this, "Zalogowano!", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, LoggedInActivity.class));
        });
    }

    private void initDb() {
        SQLiteOpenHelper helper = new SQLiteOpenHelper(this, "users.db", null, 1) {
            @Override
            public void onCreate(SQLiteDatabase db) {
                db.execSQL("CREATE TABLE IF NOT EXISTS users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "email TEXT, " +
                        "password TEXT)");
            }

            @Override
            public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            }
        };

        db = helper.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM users", null);
        if (cursor.moveToFirst() && cursor.getInt(0) == 0) {
            db.execSQL("INSERT INTO users (email, password) VALUES " +
                    "('admin@example.com', 'admin'), " +
                    "('user1@example.com', 'user1'), " +
                    "('user2@example.com', 'user2'), " +
                    "('user3@example.com', 'user3')");
        }
        cursor.close();
    }

    private boolean checkCredentials(String email, String password) {
        Cursor cursor = db.rawQuery("SELECT password FROM users WHERE email = ?", new String[]{email});
        if (cursor.moveToFirst()) {
            String storedPassword = cursor.getString(0);
            cursor.close();
            return storedPassword.equals(password);
        }
        cursor.close();
        return false;
    }
}