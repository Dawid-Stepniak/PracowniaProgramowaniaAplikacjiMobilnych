package edu.zsk.Stepniak;

import android.app.Dialog;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

public class AppDialogFragment extends DialogFragment {

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return new AlertDialog.Builder(requireContext())
                .setTitle("Dialog")
                .setMessage("To jest okno dialogowe.")
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                .create();
    }
}